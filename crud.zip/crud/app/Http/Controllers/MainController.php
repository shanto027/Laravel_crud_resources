<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Employee;


class MainController extends Controller
{
    public function index(){

         $Employee = Employee::get();

    	 return view('welcome', compact('Employee'));
    }

    public function add_employee(){
    	
    	return view('add_eployee');
    }

    public function edit_employee($id){

    	$Employee = Employee::find($id);

    	return view('edit_employee', compact('Employee'));
    }



    public function store(Request $request){

        $request->validate([

            'EmployeeName'         => 'required',
            'EmployeeDesignation'  => 'required', 
            'EmployeeEmail'        => 'required',
            'EmployeeContactNo'    => 'required', 
            'EmployeeAddress'      => 'required', 

        ]);

        $Employee = new Employee;

        $Employee->EmployeeName         = $request->EmployeeName;
        $Employee->EmployeeDesignation  = $request->EmployeeDesignation;
        $Employee->EmployeeEmail        = $request->EmployeeEmail;
        $Employee->EmployeeContactNo    = $request->EmployeeContactNo;
        $Employee->EmployeeAddress      = $request->EmployeeAddress;


        if ($request->hasfile('EmployeePhoto')) {

            $file      = $request->file('EmployeePhoto');
            $extension = $file->getClientOriginalExtension();
            $filename  = time().'.'.$extension;
            $file->move('images/',$filename);
            $Employee->EmployeePhoto = $filename;
        }

        $Employee->save();

        session()->flash('success','Successfully Data Inserted');

        return redirect()->route('home');
      
       
    }

     public function edit(Request $request, $id){

           $request->validate([

            'EmployeeName'         => 'required',
            'EmployeeDesignation'  => 'required', 
            'EmployeeEmail'        => 'required',
            'EmployeeContactNo'    => 'required', 
            'EmployeeAddress'      => 'required', 

        ]);

        $Employee = Employee::find($id);

        $Employee->EmployeeName         = $request->EmployeeName;
        $Employee->EmployeeDesignation  = $request->EmployeeDesignation;
        $Employee->EmployeeEmail        = $request->EmployeeEmail;
        $Employee->EmployeeContactNo    = $request->EmployeeContactNo;
        $Employee->EmployeeAddress      = $request->EmployeeAddress;


        if ($request->hasfile('EmployeePhoto')) {

            $file      = $request->file('EmployeePhoto');
            $extension = $file->getClientOriginalExtension();
            $filename  = time().'.'.$extension;
            $file->move('images/',$filename);
            $Employee->EmployeePhoto = $filename;
        }

        $Employee->save();

        session()->flash('success','Successfully Data Update');

        return redirect()->route('home');

     }

       public function delete($id){

          $Employee = Employee::find($id);
          $Employee->delete();
          session()->flash('success','Successfully Data delete');
          return redirect()->route('home');

       }


}
